-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 28, 2019 at 08:34 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hostel1`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(300) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updation_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `email`, `password`, `reg_date`, `updation_date`) VALUES
(1, 'admin', 'nik@gmail.com', 'admin1', '2019-01-13 12:45:33', '2019-03-12');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `course_sn` varchar(255) NOT NULL,
  `course_fn` varchar(255) NOT NULL,
  `posting_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `course_sn`, `course_fn`, `posting_date`) VALUES
(5, 'ejjjjj', 'ele egg', '2019-03-04 08:19:32'),
(6, 'cr', 'civil', '2019-03-17 10:44:08'),
(7, 'co', 'computer', '2019-03-28 17:21:41');

-- --------------------------------------------------------

--
-- Table structure for table `fee`
--

CREATE TABLE `fee` (
  `id` int(11) NOT NULL,
  `feepermonth` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fee`
--

INSERT INTO `fee` (`id`, `feepermonth`) VALUES
(1, 600);

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(11) NOT NULL,
  `fee` int(10) NOT NULL,
  `roomno` int(11) NOT NULL,
  `foodstatus` int(11) NOT NULL,
  `stayfrom` date NOT NULL,
  `duration` int(11) NOT NULL,
  `course` varchar(500) NOT NULL,
  `firstName` varchar(500) NOT NULL,
  `middleName` varchar(500) NOT NULL,
  `lastName` varchar(500) NOT NULL,
  `gender` varchar(250) NOT NULL,
  `contactno` bigint(11) NOT NULL,
  `emailid` varchar(500) NOT NULL,
  `egycontactno` bigint(11) NOT NULL,
  `guardianName` varchar(500) NOT NULL,
  `guardianRelation` varchar(500) NOT NULL,
  `guardianContactno` bigint(11) NOT NULL,
  `corresAddress` varchar(500) NOT NULL,
  `corresCity` varchar(500) NOT NULL,
  `corresState` varchar(500) NOT NULL,
  `corresPincode` int(11) NOT NULL,
  `pmntAddress` varchar(500) NOT NULL,
  `pmntCity` varchar(500) NOT NULL,
  `pmnatetState` varchar(500) NOT NULL,
  `pmntPincode` int(11) NOT NULL,
  `postingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `fee`, `roomno`, `foodstatus`, `stayfrom`, `duration`, `course`, `firstName`, `middleName`, `lastName`, `gender`, `contactno`, `emailid`, `egycontactno`, `guardianName`, `guardianRelation`, `guardianContactno`, `corresAddress`, `corresCity`, `corresState`, `corresPincode`, `pmntAddress`, `pmntCity`, `pmnatetState`, `pmntPincode`, `postingDate`, `updationDate`) VALUES
(9, 0, 103, 1, '2019-03-15', 9, 'ele egg', 'abhinav', 'ananda', 'aajgekar', 'male', 8822313114, 'abhi@gmail.com', 5555558888, 'ananda', 'father', 7777999988, 'gadhinglaj', 'gad', 'maharashtra', 416219, 'gadhinglaj', 'gad', 'maharashtra', 416219, '2019-03-17 18:46:49', ''),
(11, 400, 88, 1, '2019-03-22', 10, 'computer', 'nikhil', 'namdev', 'vharambale', 'male', 9677445699, 'nikhilvharambale@gmail.com', 8888889977, 'namdev', 'father', 8877996622, 'gargoti', 'gargoti', 'maharashtra', 416221, 'gargoti', 'gargoti', 'maharashtra', 416221, '2019-03-21 13:25:24', ''),
(12, 600, 105, 1, '2019-03-21', 7, 'civil', 'omkar', 'subhash', 'patil', 'male', 8888984627, 'om@gmail.com', 2255664477, 's', 'f', 2222111111, 'w', 'w', 'm', 1, 'w', 'w', 'm', 1, '2019-03-28 19:18:43', ''),
(13, 600, 30, 0, '2019-03-12', 7, 'computer', 'aa', 'bb', 'cc', 'male', 4444444444, 'a@gmail.com', 2222222222, 'dd', 'ff', 2222222222, 'x', 'y', 'z', 10, 'x', 'y', 'z', 10, '2019-03-28 19:23:50', '');

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `id` int(11) NOT NULL,
  `seater` int(11) NOT NULL,
  `room_no` int(11) NOT NULL,
  `posting_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`id`, `seater`, `room_no`, `posting_date`) VALUES
(5, 4, 100, '2019-03-04 08:24:59'),
(8, 4, 105, '2019-03-28 17:19:10'),
(9, 2, 80, '2019-03-28 18:56:38'),
(10, 4, 30, '2019-03-28 18:58:10'),
(11, 2, 20, '2019-03-28 19:02:37');

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `userEmail` varchar(255) NOT NULL,
  `loginTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`id`, `userId`, `userEmail`, `loginTime`) VALUES
(2, 3, 'nikhilvharambale@gmail.com', '2019-03-14 14:10:27'),
(3, 4, 'abhi@gmail.com', '2019-03-14 14:12:19'),
(4, 3, 'nikhilvharambale@gmail.com', '2019-03-14 14:19:52'),
(5, 4, 'abhi@gmail.com', '2019-03-14 14:31:07'),
(6, 4, 'abhi@gmail.com', '2019-03-14 14:33:21'),
(7, 4, 'abhi@gmail.com', '2019-03-14 14:55:18'),
(8, 3, 'nikhilvharambale@gmail.com', '2019-03-14 18:38:30'),
(9, 3, 'nikhilvharambale@gmail.com', '2019-03-14 18:40:09'),
(10, 4, 'abhi@gmail.com', '2019-03-14 18:54:34'),
(11, 3, 'nikhilvharambale@gmail.com', '2019-03-15 09:23:53'),
(12, 3, 'nikhilvharambale@gmail.com', '2019-03-15 16:03:17'),
(13, 4, 'abhi@gmail.com', '2019-03-15 16:07:57'),
(14, 3, 'nikhilvharambale@gmail.com', '2019-03-16 16:18:28'),
(39, 3, 'nikhilvharambale@gmail.com', '2019-03-28 17:07:36'),
(40, 3, 'nikhilvharambale@gmail.com', '2019-03-28 17:07:59'),
(41, 3, 'nikhilvharambale@gmail.com', '2019-03-28 19:03:35'),
(42, 6, 'om@gmail.com', '2019-03-28 19:17:40'),
(43, 3, 'nikhilvharambale@gmail.com', '2019-03-28 19:25:16'),
(44, 6, 'om@gmail.com', '2019-03-28 19:31:49');

-- --------------------------------------------------------

--
-- Table structure for table `userregistration`
--

CREATE TABLE `userregistration` (
  `id` int(11) NOT NULL,
  `firstname` char(30) NOT NULL,
  `middlename` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `contactno` bigint(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `regDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` varchar(45) NOT NULL,
  `passUdateDate` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userregistration`
--

INSERT INTO `userregistration` (`id`, `firstname`, `middlename`, `lastname`, `contactno`, `email`, `password`, `regDate`, `updationDate`, `passUdateDate`) VALUES
(2, 'mayur', 'dattatray', 'gavate', 9049838634, 'mayurgavate@gmail.com', 'ab', '2019-01-13 04:34:54', '', ''),
(3, 'nikhil', 'namdev', 'vharambale', 9677445699, 'nikhilvharambale@gmail.com', 'aabb', '2019-01-13 04:34:54', '21-03-2019 06:53:30', ''),
(4, 'abhinav', 'ananda', 'aajgekar', 8822313114, 'abhi@gmail.com', 'abcd', '2019-01-13 04:34:54', '', '14-03-2019 03:39:59'),
(5, 'ruthik', 'subrao', 'patil', 2222222222, 'ruthikpatil18@gmail.com', 'monster', '2019-03-17 12:44:05', '17-03-2019 06:15:19', ''),
(6, 'omkar', 'subhash', 'patil', 8888984627, 'om@gmail.com', 'om123', '2019-03-18 11:13:57', '18-03-2019 04:44:34', ''),
(9, 'aa', 'bb', 'cc', 4444444444, 'a@gmail.com', '4444444444', '2019-03-28 19:23:50', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fee`
--
ALTER TABLE `fee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userregistration`
--
ALTER TABLE `userregistration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `fee`
--
ALTER TABLE `fee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `userregistration`
--
ALTER TABLE `userregistration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
