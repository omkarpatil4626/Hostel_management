<?php
session_start();
include('dbc/dbconnect.php');
include('dbc/checklogin.php');
check_login();
?>

<html>
   <head>
   	  <style>

   	  .main {
          margin-top: 50px;
          border:3px solid #6E6A78;
    border-radius: 10px;
    margin-left: 80px;
    height:auto;
    margin-bottom: 30px;
      }

      .inmain {
    margin-left: 45px;}


   	  	table, th, td {
                    border: 1px solid black;
          }

          th, td {
    padding: 15px; 
    color: black;
    font-family: cursive;
      }

      th {
    text-align: left;
    color: darkmagenta;
    font-family: cursive;
    font-size: 20px;
    background-color:ghostwhite;; 
     }

      table {
    border-spacing: 2px;
    width: 90%;
    margin-top: 20px;
      
    
      }


    
 
   	  </style>
   	

   </head>

   <body>
           
           <?php include 'hmenu.php' ?>  
           <div class="main">
              <div class="inmain">
   	        <h2>Access Log Details</h2>
   	        <hr>
			<table id="zctb" class="display table table-striped table-bordered table-hover" cellspacing="0" width="100%">
												<thead>
													<tr>
														<th>Sno.</th>
														<th>User Id</th>
														<th>User Email</th>
														<th>Login Time</th>
													</tr>
												</thead>
												
												<tbody>
	<?php	
$aid=$_SESSION['id'];
$ret="select * from userlog where userId=?";
$stmt= $conn->prepare($ret) ;
$stmt->bind_param('i',$aid);
$stmt->execute() ;
$res=$stmt->get_result();
$cnt=1;
while($row=$res->fetch_object())
	  {
	  	?>
<tr><td><?php echo $cnt;;?></td>
<td><?php echo $row->userId;?></td>
<td><?php echo $row->userEmail;?></td>
<td><?php echo $row->loginTime;?></td>
										</tr>
									<?php
$cnt=$cnt+1;
									 } ?>
											
														
													
												</tbody>
											</table>
    </div>
		</div>									

    </body>

</html>