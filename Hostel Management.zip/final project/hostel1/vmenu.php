	<style>
		.sidenav {
			height: 100%;
			width: 210px;
			display: block;
			padding: 0;
			margin: 0;
			background: #4da6ff;
		}
		a {
			
			padding: 17px 15px;
			text-decoration: none;
			display: block;
			border: 1px solid #fff;
			color: #fff;
			font-size: 19px;
		}
		a:hover {
			background-color: red;
		}
	</style>

	<div class="sidenav">
	  <a href="#">Home</a>
	  <a href="#">About</a>
	  <a href="#">Services</a>
	  <a href="#">Clients</a>
	  <a href="#">Contact</a>
	</div>
