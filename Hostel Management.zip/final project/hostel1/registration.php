<?php


session_start();
include('dbc/dbconnect.php');
if(isset($_POST['submit']))
{

  if(isset($_POST['email']) && isset($_POST['psw']))
    {
         $fn=$_POST['fname'];
         $mn=$_POST['mname'];
         $ln=$_POST['lname'];
         $cn=$_POST['contact'];
         $em=$_POST['email'];
         $ps=$_POST['psw'];
        
        $result = $conn->query("select email from userregistration where email='$em' ");
        
            if($result->num_rows>0)
            {
                ?>
                                        <script type="text/javascript">
                                                alert("Email Allready Registered !!!!");
                                                location.href="registration.php";
                                        </script>
                                        <?php
                           
                        }else{
                            
                            $stmt = $conn->prepare("insert into userregistration(firstname,middlename,lastname,contactno,email,password)values(?,?,?,?,?,?)");
                            $stmt->bind_param("ssssss",$fn,$mn,$ln,$cn,$em,$ps);                            
                            $stmt->execute();
                            ?>
                            <script type="text/javascript">
                                    alert("Registered Successful!!!!");
                                    location.href="index.php";
                            </script>
                             <?php
                            
                        }
                            
                            
    }
    
 }       
        
    ?>



<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
    font-family: Arial, Helvetica, sans-serif;
  
}

* {
    box-sizing: border-box;
}

/* Add padding to containers */
.container {
    padding: 16px;
    border: 2px solid #adad85;
    width: 40%;
    box-shadow: -6px -3px 5px black;
    margin-top: 27px;
    
}

/* Full-width input fields */
input,select,textarea {
    width: 100%;
    padding: 15px;
    margin: 5px 0 22px 0;
    
    border: none;
    background: #f1f1f1;
}

input:focus {
    background-color: #ddd;
    outline: none;
}
label{
	float:left;
}
/* Overwrite default styles of hr */
hr {
    border: 1px solid #f1f1f1;
    margin-bottom: 25px;
}



input#btn {
        background-color: #4CAF50;
    color: white;
    padding: 16px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
    opacity: 0.9;}

    input#btn:hover{
        opacity: 1;
}
    } 

h1 {
    font-family: monospace;
    font-size: 36px;
    color: crimson;
    }



    button.btn.btn-default {
    float: left;
    cursor: pointer;
    font-size: 18px;
    width: 167px;
    margin-bottom: 15px;
    height: 39px;
    background-color: red;
    color: white;
   }




</style>
</head>
<body>

 <form action=" " method="post">
  <center>
  <div class="container" style="top:50">
    <h1>STUDENT REGISTRATION</h1>
    <p>Please Fill All Info.</p>
    <hr>

	<label><b>First Name :</b></label>
    <input type="text" placeholder="First Name" name="fname" required>


    <label><b>Middle Name :</b></label>
    <input type="text" placeholder="Middle Name" name="mname" required>


    <label><b>Last Name :</b></label>
    <input type="text" placeholder="Last Name" name="lname" required>
	
	<label><b>Contact No : </b></label>
	<input type="tel" placeholder="Enter mobile no" name="contact"  maxlength="10" required>
	
    <label><b>Email :</b></label>
    <input type="text" placeholder="Enter Email" name="email" required>
	

    <label><b>Password :</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required>
	
    <button class="btn btn-default" type="submit">Cancel</button>
    <input id="btn" name="submit" type="submit" value="Register" >




  </div>
</center>
</form>





</body>
</html>
