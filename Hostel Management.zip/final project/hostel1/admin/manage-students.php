<?php
session_start();
include('dbc/dbconnect.php');

if(isset($_GET['del']))
{
	$id=intval($_GET['del']);
	$adn="delete from registration where id=?";
		$stmt= $conn->prepare($adn);
		$stmt->bind_param('i',$id);
        $stmt->execute();
        $stmt->close();	   
        echo "<script>alert('Data Deleted');</script>" ;
}
?>


<html>
	
   <head>
   	  <style>

   	 .main {
    margin-top: 110px;
    border: 3px solid #6E6A78;
    border-radius: 10px;
    margin-left: 64px;
    height: auto;
    margin-bottom: 30px;
    width: 90%;
    padding:20px;}


   	  	table, th, td {
                    border: 1px solid black;
          }

          th, td {
    padding: 15px; 
    color: black;
    font-family: cursive;
      }

      th {
    text-align: left;
    color: darkmagenta;
    font-family: cursive;
    font-size: 20px;
     }

      table {
    border-spacing: 5px;
    width: 100%;
    margin-top: 20px; 
    
      }
   	  	
   	  </style>
<script language="javascript" type="text/javascript">
      var popUpWin=0;
function popUpWindow(URLStr, left, top, width, height)
{
 if(popUpWin)
{
if(!popUpWin.closed) popUpWin.close();
}
popUpWin = open(URLStr,'popUpWin', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,copyhistory=yes,width='+510+',height='+430+',left='+left+', top='+top+',screenX='+left+',screenY='+top+'');
}
</script>

      </head>


   	  <body>

   	       <?php include 'hmenu.php' ?>  
           <div class="main">


       	<h2>All Student Details</h2>
   	        <hr>
	

   	  	<table>


   	  		<thead>
				<tr>
											<th>Sno.</th>
											<th>Student Name</th>
											<th>Course Name</th>
											<th>Contact no </th>
											<th>room no </th>
											<th>Staying From </th>
											<th>Action</th>
										</tr>
			</thead>


			<tbody>
   	  	


   	  	<?php	
$aid=$_SESSION['id'];
$ret="select * from registration";
$stmt= $conn->prepare($ret) ;
//$stmt->bind_param('i',$aid);
$stmt->execute() ;//ok
$res=$stmt->get_result();
$cnt=1;
while($row=$res->fetch_object())
	  {
	  	?>
<tr><td><?php echo $cnt;;?></td>
<td><?php echo $row->firstName;?>&nbsp;<?php echo $row->middleName;?>&nbsp;<?php echo $row->lastName;?></td>
<td><?php echo $row->course;?></td>
<td><?php echo $row->contactno;?></td>
<td><?php echo $row->roomno;?></td>
<td><?php echo $row->stayfrom;?></td>
  <td><a href="javascript:void(0);"  onClick="popUpWindow('http://localhost/hostel1/admin/full-profile.php?id=<?php echo $row->id;?>');" title="View Full Details"><FONT color=blue>Detail Info </FONT></a>&nbsp;&nbsp;
	  <a href="manage-students.php?del=<?php echo $row->id;?>" onclick="return confirm("Do you want to delete");"><FONT color=red>Delete </FONT></a></td>
</tr>
												<?php
			$cnt=$cnt+1;
												 } ?>
														
													
												</tbody>
											</table>

	  </div>										

   	  </body>

   

</html>