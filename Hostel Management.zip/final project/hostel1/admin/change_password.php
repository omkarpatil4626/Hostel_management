<?php
session_start();
include('dbc/dbconnect.php');
if(isset($_POST['submit']))
{
  $op=$_POST['o_pass'];
  $np=$_POST['pass'];
  $cp=$_POST['c_pass'];

  if($np==$cp)
   {
        $sql="SELECT password FROM admin where password=?";
        $chngpwd = $conn->prepare($sql);
        $chngpwd->bind_param('s',$op);
        $chngpwd->execute();
        $chngpwd->store_result(); 
        $row_cnt=$chngpwd->num_rows;;
        if($row_cnt>0)
        {
            $con="update admin set password=?";
    $chngpwd1 = $conn->prepare($con);
    $chngpwd1->bind_param('s',$np);
      $chngpwd1->execute();?>
           <script type="text/javascript">
        alert("password changed successfully");
        location.href="change_password.php";
        </script><?php
        }
        else
        { ?>
             <script type="text/javascript">
             alert("Old password does not match");
             location.href="change_password.php";
             </script><?php
        }   
 } 

 else{
       ?>
             <script type="text/javascript">
             alert("Please check new password again ");
             location.href="change_password.php";
             </script><?php
 }  

}
?>  





<html>
<head>
    <style>
          .content {
    border: 2px solid #ffffff;
    border-radius: 5px;
    height: 100%;
    margin-left: 12%;
    margin-top: 70px;
    width: 84%;}


    .container-middle {
    margin: 30px auto auto;
    padding: 10px;
    width: 95%;}

    .container-middle form {
    border: 4px solid #6E6A78;
    border-radius: 5px;
    font-family: verdana;
    margin: auto;
    padding: 10px 110px 30px;
    width: 64%;}

    .form-title {
    border-bottom: 1px dotted #6E6A78;
    color: #3D3D3D;
    margin-top: 5px;
    padding-bottom: 10px;
    text-align: center;}

    .row {
    margin-bottom: 20px;}

    .row label {
    color: #3d3d3d;
    display: inline-block;
    font-size: 14px;
    margin: auto 19px 21px auto;
    text-align: right;
    width: 169px;}


    .container-middle .row input {
    border: 1px solid #6e6a78;
    display: inline-block;
    margin: auto;
    padding: 8px;
    width: 52%;}

    .button input {
    background-color: #34495e;
    border: 0 none;
    border-radius: 8px;
    color: #fff;
    font-size: 12px;
    font-weight: bold;
    height: 40px;
    margin: 10px 2px;
    width: 100px;
    cursor: pointer;

    }



 
    </style>

</head>

<body>
<div>
         <?php include 'hmenu.php' ?> 
           
        <div class="content">            
            <div class="demo container-middle">
                <form action=" " method="post">
                <h1 class="form-title">Change_password</h1><br><br>
               
          
                <div class="row">
                <label>Old password : </label>
                    <input type="password" placeholder="Enter password" id="old_password"  name="o_pass" required="" >
                <label>new password :</label>
                    <input type="password" placeholder="new Password" id="new_password" name="pass" required="" >
               
                    <label>confirm password : </label>
                    <input type="password" placeholder="confirm password" id="confirm_password" name="c_pass" required="" >
                </div>                

                                
                <div class="button">
                        <center>
                            <input type="submit" name="submit" value="Update">
                        </center>
                        
               </div>
        
                    
         </form>
                <br>
                
            </div>

        </div>
       
 </div>       
</body>
</html>