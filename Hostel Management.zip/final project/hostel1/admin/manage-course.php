<?php
session_start();
include('dbc/dbconnect.php');


if(isset($_GET['del']))
{
	$id=intval($_GET['del']);
	$adn="delete from courses where id=?";
		$stmt= $conn->prepare($adn);
		$stmt->bind_param('i',$id);
        $stmt->execute();
        $stmt->close();	   
        echo "<script>alert('Data Deleted');</script>" ;
}
?>

<html>
   <head>
   	  <style>

   	  .main {
    margin-top: 110px;
    border: 3px solid #6E6A78;
    border-radius: 10px;
    margin-left: 64px;
    height: auto;
    margin-bottom: 30px;
    width: 90%;
    padding:20px;}


   	  	table, th, td {
                    border: 1px solid black;
          }

          th, td {
    padding: 15px; 
    color: black;
    font-family: cursive;
      }

      th {
    text-align: left;
    color: darkmagenta;
    font-family: cursive;
    font-size: 20px;
     }

      table {
    border-spacing: 5px;
    width: 100%;
    margin-top: 20px; 
    
      }

   


    
 
   	  </style>
   	

   </head>

   <body>
           
           <?php include 'hmenu.php' ?>  
           <div class="main">
   	        <h2>All Course Details</h2>
   	        <hr>
			<table id="zctb" class="display table table-striped table-bordered table-hover" cellspacing="0" width="100%">
												<thead>
													<tr>
														<th>Sno.</th>
														<th>Course Name(Short)</th>
														<th>Course Name(Full)</th>
														<th>Reg Date </th>
														<th>Action</th>
													</tr>
												</thead>
												
												<tbody>
			<?php	
			$aid=$_SESSION['id'];
			$ret="select * from courses";
			$stmt= $conn->prepare($ret) ;
			//$stmt->bind_param('i',$aid);
			$stmt->execute() ;//ok
			$res=$stmt->get_result();
			$cnt=1;
			while($row=$res->fetch_object())
				  {
				  	?>
			<tr><td><?php echo $cnt;;?></td>
			<td><?php echo $row->course_sn;?></td>
			<td><?php echo $row->course_fn;?></td>
			<td><?php echo $row->posting_date;?></td>
			<td><a href="edit-course.php?id=<?php echo $row->id;?>"><FONT color=blue>Update </FONT></a>&nbsp;&nbsp;
			<a href="manage-course.php?del=<?php echo $row->id;?>" onclick="return confirm("Do you want to delete");"><FONT color=red>Delete </FONT></a></td>
													</tr>
												<?php
			$cnt=$cnt+1;
												 } ?>
														
													
												</tbody>
											</table>

		</div>									

    </body>

</html>