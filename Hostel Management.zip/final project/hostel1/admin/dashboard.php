<?php
		session_start();
		include('dbc/dbconnect.php');
		?>
<html>
	
	<head>
		<style>
			.first {
                    border: 2px solid blue;
                    border-radius: 8px;
                width: 275px;
                height: 136px;
                background-color:#325d88;
                color: white;
            }

             .firsta {
         margin: 40px 0 8px 117px;
         font-size: 26px;}

    .firstb {
         margin-left: 94px;
         font-size: 26px;}

           


            .fmain {
            	float: left;
                border: 2px solid black;
                border-radius: 8px;
               width: 278px;
             height: 178px;
             color: white;
             margin-left: 70px;
                 margin-top: 50px;
              }



              .second {
                    border: 2px solid green;
                     border-radius: 8px;
                width: 275px;
                height: 136px;
                background-color:#93c54b;
                color: white;
            }

             .seconda {
    margin: 40px 0 8px 117px;
         font-size: 26px;}

    .secondb {
    margin-left: 76px;
         font-size: 26px;}

          


            .smain {
            	float: left;
                border: 2px solid black;
                border-radius: 8px;
               width: 278px;
             height: 178px;
             color: white;
                 margin-left: 70px;
                     margin-top: 50px;
              }



     .third {
                    border: 2px solid darkblue;
                     border-radius: 8px;
                width: 275px;
                height: 136px;
                background-color:#29abe0;
                color: white;
            }

             .thirda {
    margin: 40px 0 8px 117px;
         font-size: 26px;}

    .thirdb {
    margin-left: 74px;
         font-size: 26px;}

         .fst a{font-size: 15px;
    line-height: 32px;
    font-weight: 500;
    text-transform: uppercase;
         color: black;
    margin-left: 15px}


            .tmain {
            	float: left;
                border: 2px solid black;
                border-radius: 8px;
               width: 278px;
             height: 178px;
             color: white;
                 margin-left: 70px;
                     margin-top: 50px;
              } 



              .fst {
    border: 4px solid #6E6A78; 
    border-radius: 5px;   
    margin-top: 183px;
    width: 1172px;;
    height: 406px;
    margin-left: 172px;} 


    h2 {
    font-family: monospace;
    font-size: 30px;
    color: crimson;
     margin: 18px;}

    hr {
    margin: 17px;}       

		</style>
		
	</head>

	<body>

		<?php include 'hmenu.php' ?> 
    
    <div class=fst>	
    	

    <h2>Dashboard </h2>	
    <hr>
		
		<?php
$result ="SELECT count(*) FROM registration ";
$stmt = $conn->prepare($result);
$stmt->execute();
$stmt->bind_result($count);
$stmt->fetch();
$stmt->close();
?>    <div class="fmain">
	       <div class="first"> 
		       <div class="firsta "><?php echo $count;?></div>
			   <div class="firstb"> Students</div>
			   </div>
				<a href="manage-students.php">Full Details-></a>
			   
	       </div>
	    


	    <?php
$result1 ="SELECT count(*) FROM rooms ";
$stmt1 = $conn->prepare($result1);
$stmt1->execute();
$stmt1->bind_result($count1);
$stmt1->fetch();
$stmt1->close();
?>				

         <div class="smain">
	       <div class="second"> 
		       <div class="seconda "><?php echo $count1;?></div>
			   <div class="secondb">Total Rooms</div>
			   </div>
				<a href="manageroom.php">See All-></a>
			   
	       </div>


<?php
$result2 ="SELECT count(*) FROM courses ";
$stmt2 = $conn->prepare($result2);
$stmt2->execute();
$stmt2->bind_result($count2);
$stmt2->fetch();
$stmt2->close();
?>	

	        <div class="tmain">
	       <div class="third"> 
		       <div class="thirda "><?php echo $count2;?></div>
			   <div class="thirdb">Total Courses</div>
			   </div>
				<a href="manage-course.php">See All-></a>
			   
	       </div>	


   
</div>	       							
	   
	</body>
</html>