<?php
session_start();
include('dbc/dbconnect.php');
//code for add courses
if(isset($_POST['submit']))
{
$seater=$_POST['seater'];
$roomno=$_POST['rno'];
/*$fees=$_POST['fee'];*/
$sql="SELECT room_no FROM rooms where room_no=?";
$stmt1 = $conn->prepare($sql);
$stmt1->bind_param('i',$roomno);
$stmt1->execute();
$stmt1->store_result(); 
$row_cnt=$stmt1->num_rows;;
if($row_cnt>0)
{
echo"<script>alert('Room alredy exist');</script>";
}
else
{
$query="insert into  rooms (seater,room_no) values(?,?)";
$stmt = $conn->prepare($query);
$rc=$stmt->bind_param('ii',$seater,$roomno);
$stmt->execute();
echo"<script>alert('Room has been added successfully');
</script>";
}
}
?>



<html>
	
	<head>
		<style>
			.main {
    				
    				width: 33%;
    				margin-top: 136px;
   					margin-left: 29%;
    				padding: 37px;
    				background: dimgrey;
    				box-shadow: -5px 10px 6px;
                    }


             table {
                  line-height: 55px; 
                  }

             form {
                   margin: 32px;  
                   }  

                   label {
    				font-size: 20px;
   					 font-family: arial;
    				color: yellow;
    				}

    		input[type="text"] {
   								 width: 250px;
    							border: 1px solid black;
   								border-radius: 6px;
    							height: 37px;
    							margin-left: 22px;
    							}

    		select#seater {
                                width: 250px;
                                border: 1px solid black;
   							 	border-radius: 6px;
    							height: 37px;
    							margin-left: 22px;	
    							}

    		button.registerbtn {
								    color: white;
								    border: 1px solid white;
								    background: black;
								    padding: 7px;
								    border-radius: 11px;
								    font-size: 17px;
								    cursor: pointer;
								    margin-top: 14px  
								    }

					h1{color:white;
					       }			    											             
		</style>
	</head>

	<body>

    <?php include('hmenu.php');?>

		<div class=main>
		<h1>Add A Room</h1>
		<hr>
    
		<form action=" " method="post">
			<table>
				<tr>
				  <td><label>Select seater :</label></td>
				  <td>
				  	   <select id="seater" name="seater">
				  	   <option value="">Select Seater</option>
                       <option value="2">Two Seater</option>
                       <option value="4">Four Seater</option>
	                   </select>
	              </td>
			    </tr>

			    <tr>
				  <td><label>Room No:</label></td>
				  <td><input type="text" name="rno"></td>
			    </tr>

			    
			    

			    <tr>
			    	<td>
			    		<button type="submit" name="submit" class="registerbtn">Create Room</button>
			    		
			    	</td>
			    </tr>	
			</table>
		</form>
	</div>
	</body>
</html>