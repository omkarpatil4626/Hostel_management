<?php
session_start();
include('dbc/dbconnect.php');
//code for add courses
if(isset($_POST['submit']))
{
	/*$coursecode=$_POST['cc'];*/
	$coursesn=$_POST['cns'];
	$coursefn=$_POST['cnf'];

	$query="insert into  courses (course_sn,course_fn) values(?,?)";
	$stmt = $conn->prepare($query);
	$rc=$stmt->bind_param('ss',$coursesn,$coursefn);
	$stmt->execute();
	echo"<script>alert('Course has been added successfully');</script>";
}?>



<html>
	
	<head>
		<style>
			.main {
    				
    				width: 33%;
    				margin-top: 136px;
   					margin-left: 29%;
    				padding: 37px;
    				background: dimgrey;
    				box-shadow: -5px 10px 6px;
                    }


             table {
                  line-height: 55px; 
                  }

             form {
                   margin: 32px;  
                   }  

                   label {
    				font-size:17px;
   					 font-family: arial;
    				color: yellow;
    				}

    		input[type="text"] {
   								 width: 250px;
    							border: 1px solid black;
   								border-radius: 6px;
    							height: 32px;
    							margin-left: 22px;
    							}

    		

    		button.registerbtn {
								    color: white;
								    border: 1px solid white;
								    background: black;
								    padding: 7px;
								    border-radius: 11px;
								    font-size: 18px;
								    cursor: pointer;
								    margin-top: 14px ;
								    width: 120px; 
								    }

					h1{color:white;
					       }			    											             
		</style>	</head>

	<body>

    <?php include('hmenu.php');?>

		<div class=main>
		<h1>Add Course</h1>
		<hr>
    
		<form action=" " method="post">
			<table>
				

			    <tr>
				  <td><label>Course Name(short):</label></td>
				  <td><input type="text" name="cns"></td>
			    </tr>

			    <tr>
			    	<td><label>Course Name(full):</label></td>
			    	<td><input type="text" name="cnf"></td>
			    </tr>

			    <tr>
			    	<td>
			    		<button type="submit" name="submit" class="registerbtn">Add</button>
			    	</td>
			    </tr>	
			</table>
		</form>
	</div>
	</body>
</html>