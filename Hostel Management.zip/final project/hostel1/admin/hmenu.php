<style>
*{margin:0px;
		    padding:0px;}
			
	     #Menu ul{
		   list-style:none;
		   
		 }
		 
		 #Menu ul li{
		     background-color:#3C3E94;
			 width: 187px;
			 border:1px solid white;
			 height:53px;
			 line-height:50px;
			 text-align:center;
			 float:left;
			 color:white;
			 font-size:21px;
		 }
		 
		 #Menu ul li:hover
		 {
			 
			 background-color:#388222;
			 
		 }
		 
		  #Menu ul ul{
			  display:none;
		  }
		  
		  #Menu ul li:hover > ul
		  {
			  
			  display:block;
		  }
		  
		  a {
    text-decoration: none;
    cursor: pointer;
		  color: white;}
		  
		  #Menu {
   			 border: 1px solid red;
    		width: 100%;
		  	height: 57px;
			}



	
</style>
      <div id="Menu">
	    <ul>
		   
		   <li><a href="dashboard.php">Home</a></li>
		   <li>Course
		        <ul>
			      <li><a href="add_course.php">Add a Course</a></li>
				  <li><a href="manage-course.php">Manage Courses</a></li>
				   
			  </ul>
		   
		   </li>
		      
		   <li>Rooms
		      <ul>
			      <li><a href="addroom.php">Add a Room</a></li>
				  <li><a href="manageroom.php">Manage Rooms</a></li>
				   
			  </ul>
		   </li>

		   <li><a href="updatefee.php">Fee</a></li>
		   <li><a href="manage-students.php">Manage Students</a></li>
		   


             <li><a href="registration.php">Student Registration</a></li>

              <li>Account
			    <ul>
			      <li><a href="admin-profile.php">Admin Profile</a></li>
			      <li><a href="change_password.php">Change Password</a></li>
				 
				   
			  </ul>
			
			</li>
			 <li><a href="logout.php">Logout</a></li>
		</ul>
	  </div>
  