<?php
		$conn=new mysqli("localhost","root","","hostel1");
?>
         