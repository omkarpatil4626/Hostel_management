<?php
session_start();  
session_destroy();
header("Location: http://localhost/hostel1/index.php");
?>