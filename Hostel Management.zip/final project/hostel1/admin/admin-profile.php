<?php
session_start();
include('dbc/dbconnect.php');
//code for update email id
if(isset($_POST['update']))
{
$email=$_POST['emailid'];
$unm=$_POST['uname'];
$aid=$_SESSION['id'];
$udate=date('Y-m-d');  
$query="update admin set email=?,username=?,updation_date=? where id=?";
$stmt = $conn->prepare($query);
$rc=$stmt->bind_param('sssi',$email,$unm,$udate,$aid);
$stmt->execute();
echo"<script>alert('data has been successfully updated');</script>";
}?>

<html>
<head>
    <style>
          .content {
    border: 2px solid #ffffff;
    border-radius: 5px;
    height: 100%;
    margin-left: 12%;
    margin-top: 70px;
    width: 84%;}


    .container-middle {
    margin: 30px auto auto;
    padding: 10px;
    width: 95%;}

    .container-middle form {
    border: 4px solid #6E6A78;
    border-radius: 5px;
    font-family: verdana;
    margin: auto;
    padding: 10px 110px 30px;
    width: 64%;}

    .form-title {
    border-bottom: 1px dotted #6E6A78;
    color: #3D3D3D;
    margin-top: 5px;
    padding-bottom: 10px;
    text-align: center;}

    .row {
    margin-bottom: 20px;}

    .row label {
    color: #3d3d3d;
    display: inline-block;
    font-size: 14px;
    margin: auto 19px 21px auto;
    text-align: right;
    width: 169px;}


    .container-middle .row input {
    border: 1px solid #6e6a78;
    display: inline-block;
    margin: auto;
    padding: 8px;
    width: 52%;}

    .button input {
    background-color: #34495e;
    border: 0 none;
    border-radius: 8px;
    color: #fff;
    font-size: 12px;
    font-weight: bold;
    height: 40px;
    margin: 10px 2px;
    width: 100px;
    cursor: pointer;

    }



 
    </style>

</head>

<body>
<div>
	<?php include ('hmenu.php');    
     $aid=$_SESSION['id'];
    $ret="select * from admin where id=?";
    $stmt= $conn->prepare($ret) ;
     $stmt->bind_param('i',$aid);
     $stmt->execute() ;//ok
     $res=$stmt->get_result();
     //$cnt=1;
       while($row=$res->fetch_object())
      {
        ?>
                   
 <div class="content">            
     <div class="demo container-middle">
         <form action=" " method="post">
            	<h1 class="form-title">Admin Profile</h1><br><br>
               
          
               <div class="row"> 
				<label>Username : </label>
                    <input type="text" name="uname" value="<?php echo $row->username;?>" >
				<label>Email :</label>
                    <input type="email" name="emailid" value="<?php echo $row->email;?>"  >
               
                    <label>Reg Date : </label>
                    <input type="text" value="<?php echo $row->reg_date;?>" disabled>
                </div>                

                                
                <div class="button">
                        <center>
                            <input type="submit" name="update" value="Update">
                        </center>
					
		        </div>
    <?php } ?>  
		
					
		 </form>
                <br>
                
            </div>

        </div>
       
 </div>       
</body>
</html>