<html>
	<head>
		<title>Menu</title>
	</head>
	
	<style>
	   body
{
	margin:0;
	padding:0;
	background:url(image.jpg);
	background-size:100%;
}
.sidebar
{
	position:fixed;
	top:0;
	left:-21%;
	margin:0;
	padding:0;
	width:21%;
	height:100%;
	background:rgba(0,0,0,0.95);
	transition:0.5;
}
.sidebar.active
{
	left:0;
	transition:0.5s;
}
.toggle
{
	position:absolute;
	width:70px;
	height:70px;
	top:45%; 
	right:-70px;
	background:yellow;
	transition:0.5s;
	cursor:pointer;
	display:flex;
	align-items:center;
	justify-content:center;
}
.toggle:before
{
	position:relative;
	content:'';
	left:-10px;
	width:30px;
	height:30px;
	border-top:4px solid black;
	border-right:4px solid black;
	transform:rotate(45deg);
	transition:0.5s;
}
.sidebar.active .toggle:before
{
	transform:rotate(225deg);
	left:10px;
}
.sidebar ul
{
	padding:20px;
	margin:0;
	transform:translateX(-100%);
}
.sidebar.active ul
{
	transform:translateX(0);
	transition-delay:0.2s;
}
.sidebar ul li
{
	list-style:none;
}
.sidebar ul li a
{
	position:relative;
	padding:10px 10px;
	color:white;
	font-family:monospace;
	font-size:30px;
	text-decoration:none;
	display:inline-block;
	z-index:2;
	transition:0.5s;
	text-shadow:0 2px 10px rgba(0,0,0,0.2);
	text-transform:uppercase;
	
}
.sidebar ul li a:hover
{
	letter-spacing:5px;
	transform:translateX(20px);
}
.sidebar ul li a:before
{
	content:'';
	bottom:0;
	left:0;
	position:absolute;
	width:100%;
	height:80%;
    background: orangered;
	z-index:-1;
	transform:scaleX(0);
	transform-origin:right;
	transition:transform 0.5s;
}

.sidebar ul li a:hover:before
{
	transform:scaleX(1);
	transform-origin:left;
	transition:transform 0.5s;
}



    h1 {
    text-align: center;
     border: 1px solid black;
    height: 71px;
    width: 99%;
    background-color: aliceblue;
    /*position: fixed;*/
    margin-top: 0px;
    margin-left: 10px;
   
    }


	
	
	</style>
	
	
	
	<body>
             <h1>Hostel Management System</h1>

			<div class="sidebar" id="sidebar">
			<div class="toggle" onclick="toggle_div()">
			</div>
			<ul>
					<li><a href="dashboard.php">Dashboard</a></li>
					<li><a href="my-profile.php">My Profile</a></li>
					<li><a href="change-password.php">Change pass. </a></li>
					<li><a href="book-hostel.php">Book Hostel</a></li>
					<li><a href="room-details.php">Room Details</a></li>
					<li><a href="access-log.php">Access Log</a></li>
					<li><a href="logout.php">Logout</a></li>
			</ul>
			</div>
			<script type="text/javascript">
				function toggle_div()
				{
					var element = document.getElementById('sidebar');
					element.classList.toggle('active')
				}
			</script>
	</body>

</html>