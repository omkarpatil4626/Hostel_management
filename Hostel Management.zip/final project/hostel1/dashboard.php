<?php
		session_start();
		include('dbc/dbconnect.php');
        include('dbc/checklogin.php');
        check_login();
		?>
<html>
	
	<head>
		<style>
			.first {
                    border: 2px solid blue;
                    border-radius: 8px;
                width: 275px;
                height: 136px;
                background-color:#325d88;
                color: white;
            }

             .firsta {
         margin: 40px 0 8px 117px;
         font-size: 40px;
         margin-left: 45px;}

    
           


            .fmain {
            	float: left;
                border: 2px solid black;
                border-radius: 8px;
               width: 278px;
             height: 178px;
             color: white;
             margin-left: 160px;
                 margin-top: 50px;
              }



              .second {
                    border: 2px solid green;
                     border-radius: 8px;
                width: 275px;
                height: 136px;
                background-color:#93c54b;
                color: white;
            }

             .seconda {
    margin: 40px 0 8px 117px;
         font-size: 40px;
    margin-left: 45px;}

  

          


            .smain {
            	float: left;
                border: 2px solid black;
                border-radius: 8px;
               width: 278px;
             height: 178px;
             color: white;
                 margin-left: 159px;
                     margin-top: 50px;
              }




         .fst a{font-size: 15px;
    line-height: 32px;
    font-weight: 500;
    text-transform: uppercase;
         color: black;
    margin-left: 15px}




              .fst {
    border: 4px solid #6E6A78; 
    border-radius: 5px;   
    margin-top: 100px;
    width: 1172px;;
    height: 406px;
    margin-left: 172px;} 


    h2 {
    font-family: monospace;
    font-size: 30px;
    color: crimson;
     margin: 18px;}

    hr {
    margin: 17px;}       

		</style>
		
	</head>

	<body>


       <?php include 'hmenu.php' ?> 


		
    
    <div class=fst>	
    	

    <h2>Dashboard </h2>	
    <hr>
		
   <div class="fmain">
	       <div class="first"> 
		       <div class="firsta ">My Profile</div>
			   
			   </div>
				<a href="my-profile.php">Full Details-></a>
			   
	       </div>
	    


				

         <div class="smain">
	       <div class="second"> 
		       <div class="seconda ">My Room</div>
			   
			   </div>
				<a href="room-details.php">See All-></a>
			   
	       </div>




	     


   
</div>	       							
	   
	</body>
</html>