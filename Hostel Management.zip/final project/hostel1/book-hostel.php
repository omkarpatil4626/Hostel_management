<?php
session_start();
include('dbc/dbconnect.php');
include('dbc/checklogin.php');
check_login();
//code for registration
if(isset($_POST['submit']))
{
$fe=$_POST['fee'];
$roomno=$_POST['room'];
$foodstatus=$_POST['foodstatus'];
$stayfrom=$_POST['stayf'];
$duration=$_POST['duration'];
$course=$_POST['course'];

$fname=$_POST['fname'];
$mname=$_POST['mname'];
$lname=$_POST['lname'];
$gender=$_POST['gender'];
$contactno=$_POST['contact'];
$emailid=$_POST['email'];
$emcntno=$_POST['econtact'];
$gurname=$_POST['gname'];
$gurrelation=$_POST['grelation'];
$gurcntno=$_POST['gcontact'];
$caddress=$_POST['address'];
$ccity=$_POST['city'];
$cstate=$_POST['state'];
$cpincode=$_POST['pincode'];
$paddress=$_POST['paddress'];
$pcity=$_POST['pcity'];
$pstate=$_POST['pstate'];
$ppincode=$_POST['ppincode'];
$query="insert into registration(fee,roomno,foodstatus,stayfrom,duration,course,firstName,middleName,lastName,gender,contactno,emailid,egycontactno,guardianName,guardianRelation,guardianContactno,corresAddress,corresCIty,corresState,corresPincode,pmntAddress,pmntCity,pmnatetState,pmntPincode) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
$stmt = $conn->prepare($query);
$rc=$stmt->bind_param('iiisisssssisississsisssi',$fe,$roomno,$foodstatus,$stayfrom,$duration,$course,$fname,$mname,$lname,$gender,$contactno,$emailid,$emcntno,$gurname,$gurrelation,$gurcntno,$caddress,$ccity,$cstate,$cpincode,$paddress,$pcity,$pstate,$ppincode);
$stmt->execute();
$stmt->close();
echo"<script>alert('Student Succssfully register');</script>";
}
?>

<html>
  
  <head>
<style>

      h2 {
        background-color: 85918F;
        margin: 0;
        padding: 22px;
        text-align: center;
        color: fff;
        font-family: sans-serif;
      }

          .content {
    border: 2px solid #ffffff;
    border-radius: 5px;
    height: 100%;
    margin-left: 12%;
    margin-top: 70px;
    width: 84%;

  }


    .container-middle {
    margin: 30px auto auto;
    padding: 10px;
    width: 95%;}

    .container-middle form {
    border: 4px solid #6E6A78;
    font-family: verdana;
    margin: auto;
    padding: 10px 110px 30px;
    width: 64%;
    border-radius: 8px;
    background-color: F6F6F6;
    margin-left: 86px;
  }

    .form-title {
    border-bottom: 1px dotted #6E6A78;
    color: #3D3D3D;
    margin-top: 5px;
    padding-bottom: 10px;
    text-align: center;}

    .row {
    margin-bottom: 20px;}

    .row label {
    color: #3d3d3d;
    display: inline-block;
    font-size: 14px;
    margin: auto 19px 21px auto;
    text-align: right;
    width: 169px;}


    .container-middle .row input {
    border: 1px solid #6e6a78;
    display: inline-block;
    margin: auto;
    padding: 8px;
    width: 52%;}

    .button input {
    background-color: #34495e;
    border: 0 none;
    border-radius: 8px;
    color: #fff;
    font-size: 12px;
    font-weight: bold;
    height: 40px;
    margin: 10px 2px;
    width: 100px;
    cursor: pointer;

    }

    .row input[type="radio"] {
        width: 20px;
        height: 20px;
       
      }


   .content .container-middle .row select {
        width: 52%;
        height: 36px;
       
      }

      textarea {
    width: 52%;}

    label.col-sm-5.control-label {
    width: 500px;
     color:red;}

    input#adcheck {
    width: 15px;}

   



 
    </style>

    <script>
function getSeater(val) {
$.ajax({
type: "POST",
url: "get_seater.php",
data:'roomid='+val,
success: function(data){
//alert(data);
$('#seater').val(data);
}
});

$.ajax({
type: "POST",
url: "get_seater.php",
data:'rid='+val,
success: function(data){
//alert(data);
$('#fpm').val(data);
}
});
}
</script>



     <script type="text/javascript">
            function auto_fill_address()
            {
                var same_addr = document.getElementById("adcheck").checked;
                var resaddr = document.getElementById("address").value;
                var ct = document.getElementById("city").value;
                var stt = document.getElementById("state").value;
                var respin = document.getElementById("pincode").value;
            
                // this if will execute if same address is checked .
                
                if(same_addr)
                {
                    if((resaddr=='' || resaddr==null)||(ct=='' || ct==null)||(stt=='' || stt==null)||(respin=='' || respin==null))
                        {
                        alert('please fill address and pincode');
                        document.getElementById("adcheck").checked = false;
                        }
                    else
                        {
                        document.getElementById("paddress").value = resaddr;
                        document.getElementById("pcity").value = ct;
                        document.getElementById("pstate").value = stt;
                        document.getElementById("ppincode").value = respin;
                        }
                }
                // no checked
                else
                 {
                    document.getElementById("paddress").value = '';
                    document.getElementById("pcity").value = '';
                    document.getElementById("pstate").value = '';
                    document.getElementById("ppincode").value = '';
                }  
            }
   </script>

    

  </head>

  <body>

    <?php include('hmenu.php');?>
   <div class="content">            
      <div class="demo container-middle">
    
      <form action=" " method="post">

                <?php
               $uid=$_SESSION['login'];
               $stmt=$conn->prepare("SELECT emailid FROM registration WHERE emailid=? ");
        $stmt->bind_param('s',$uid);
        $stmt->execute();
        $stmt -> bind_result($email);
        $rs=$stmt->fetch();
        $stmt->close();
        if($rs)
        { ?>
      <h3 style="color: red" align="left">Hostel is booked by you</h3>
        <?php }
        else{
              echo "";
              }     
              ?>  
     
        <h2><center>REGISTRATION FORM</center></h2>
        <hr><br><br>

     
        <div class="row">

          <fieldset>
            <legend>ROOM RELATED INFO</legend>

            <?php   
    
     $ret3="select * from fee where id=1";
     $stmt3= $conn->prepare($ret3) ;
     $stmt3->execute() ;//ok
     $res3=$stmt3->get_result();
       while($row3=$res3->fetch_object())
      {
        ?>     
                
                        <label>Fee(per month) :</label>
                        <input type="text" name="fee" value="<?php echo $row3->feepermonth;?>"  readonly><br><br>
               
                   
                 

        <?php } ?> 
            
            <label>ROOM NO:</label>
                    <select name="room" id="room" class="form-control" onChange="getSeater(this.value);" onBlur="checkAvailability()" required> 
                      <option value="">Select Room</option>
                      <?php $query ="SELECT * FROM rooms";
                      $stmt2 = $conn->prepare($query);
                      $stmt2->execute();
                      $res=$stmt2->get_result();
                      while($row=$res->fetch_object())
                      {
                      ?>
                      <option value="<?php echo $row->room_no;?>"> <?php echo $row->room_no;?></option>
                      <?php } ?>
                      </select><br> 

                      <span id="room-availability-status" style="font-size:12px; color=red"></span>
              
               <br> 


                 
                     <label>Food Status:</label>
                      
                     <input type="radio" value="0" name="foodstatus" > Without Food  
                     <input type="radio" value="1" name="foodstatus" >With Food(Rs 2000.00 Per Month Extra)         
                <br>


                
                  <label>Stay From:</label>
                  <input type="date" name="stayf" >
                <br> 


                  <label>Duration:</label>
                    <select name="duration" id="duration" class="form-control">
                      <option value="">Select Duration in Month</option>
                      <option value="1">1</option>
                      <option value="2">2</option>
                      <option value="3">3</option>
                      <option value="4">4</option>
                      <option value="5">5</option>
                      <option value="6">6</option>
                      <option value="7">7</option>
                      <option value="8">8</option>
                      <option value="9">9</option>
                      <option value="10">10</option>
                      <option value="11">11</option>
                      <option value="12">12</option>
                    </select>


             </fieldset><br><br>





      <fieldset>
      <legend>Pesonal Information</legend>
      
        <label>course: </label>
        
        <select name="course" id="course" class="form-control" required> 
            <option value="">Select Course</option>
            <?php $query ="SELECT * FROM courses";
            $stmt2 = $conn->prepare($query);
            $stmt2->execute();
            $res=$stmt2->get_result();
            while($row=$res->fetch_object())
            {
            ?>
            <option value="<?php echo $row->course_fn;?>"><?php echo $row->course_fn;?>&nbsp;&nbsp;(<?php echo $row->course_sn;?>)</option>
            <?php } ?>
        </select>
       <br>
         

         <?php  
    $aid=$_SESSION['id'];
    $ret="select * from userregistration where id=?";
    $stmt= $conn->prepare($ret) ;
   $stmt->bind_param('i',$aid);
   $stmt->execute() ;//ok
   $res=$stmt->get_result();
   //$cnt=1;
     while($row=$res->fetch_object())
    {
      ?>
       
       
       

       <label>First Name : </label> 
       <input type="text" name="fname" id="lname"  value="<?php echo $row->firstname;?>" readonly><br><br>

       <label>Middle Name : </label>
       <input type="text" name="mname" id="mname" value="<?php echo $row->middlename;?>"  readonly><br><br>

       <label>Last Name : </label>
       <input type="text" name="lname" id="lname"  value="<?php echo $row->lastname;?>" readonly><br><br>


       <label>Contact No : </label> 
       <input type="text" name="contact" maxlength="10" value="<?php echo $row->contactno;?>" readonly><br><br>

       <label>Email id : </label>
       <input type="text" placeholder="Enter Email" name="email" value="<?php echo $row->email;?>"  readonly><br><br>

     <?php } ?>


      <label>Gender : </label>
        <select name="gender" class="form-control" required="required">
              <option value="">Select Gender</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
          
          </select><br><br>

        <label>Emergency Contact: </label>
        <input type="text" name="econtact" maxlength="10" required="required"><br><br>

        <label>Guardian  Name : </label>
        <input type="text" name="gname" required="required"><br><br>

         <label>Guardian  Relation : </label>
         <input type="text" name="grelation" id="grelation"  class="form-control" required="required"><br><br>

         <label>Guardian Contact no : </label>
         <input type="text" name="gcontact" required="required"><br><br>

     </fieldset><br><br>

     <fieldset>
        <legend>Correspondense Address </legend>

          <label>Address : </label>
          <textarea  rows="5" name="address" id="address" required="required"></textarea><br><br>

          <label>City : </label>
          <input type="text" name="city" id="city" required="required"><br><br>

          <label>State </label>
          <input type="text" name="state" id="state" required="required"><br><br>

          <label>Pincode : </label>
          <input type="text" name="pincode" id="pincode" required="required"><br><br>



     </fieldset>

      <div class="form-group">
        <label class="col-sm-5 control-label">Permanent Address same as Correspondense address : </label>
        <input type="checkbox" name="adcheck" id="adcheck" value="abcd" onclick="return auto_fill_address();" />
      </div>
  
     <fieldset>
        <legend>Permanent Address </legend>
         
          <label>Address : </label>
          <textarea  rows="5" name="paddress" id="paddress" required="required"></textarea><br><br>

          <label>City : </label>
          <input type="text" name="pcity" id="pcity" required="required"><br><br>

          <label>State </label>
          <input type="text" name="pstate" id="pstate" required="required"><br><br>

          <label>Pincode : </label>
          <input type="text" name="ppincode" id="ppincode" required="required"><br><br>
         

      </fieldset><br>

      

      <div class="button">
      <input id="btn" name="submit" type="submit" value="Register" >       
      </div>  
        
    
  






    




          </div>


        </form>
    </div>
  </div>
  </body>
 


 



</html> 