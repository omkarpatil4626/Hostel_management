<?php
session_start();
include('dbc/dbconnect.php');
//include('dbc/checklogin.php');
//check_login();
?>

<head>
	   	  <style>

   	  


   	  	table, th, td {
                    border: 1px solid black;
          }

          th, td {
    padding: 15px; 
    color: black;
    font-family: cursive;
      }

      th {
    text-align: left;
    color: darkmagenta;
    font-family: cursive;
    font-size: 20px;
     }

      table {
    border-spacing: 0px;
    width: 90%;
    margin-top: 20px;
    border: 2px solid red; 
    
      }


       .main {
    border:3px solid #6E6A78;
    border-radius: 10px;
    margin-top: 50px;
    margin-left: 80px;
    height: 800px;
    margin-bottom: 30px;}

    .inmain {
    margin-left: 35px;}

    h4 {
    color: rebeccapurple;}
  
 



    
 
   	  </style>


      <script language="javascript" type="text/javascript">
var popUpWin=0;
function popUpWindow(URLStr, left, top, width, height)
{
 if(popUpWin)
{
if(!popUpWin.closed) popUpWin.close();
}
popUpWin = open(URLStr,'popUpWin', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,copyhistory=yes,width='+510+',height='+430+',left='+left+', top='+top+',screenX='+left+',screenY='+top+'');
}

</script>

</head>

<html>

<body>
	
     <?php include('hmenu.php');?>

                        <div class="main"> 
	                    <div class="inmain"> 
						<h2 class="page-title">Rooms Details</h2>
						
							<div class="panel-heading">All Room Details</div>
							<div class="panel-body">
                          <table>
									
									
<tbody>
<?php	
$aid=$_SESSION['login'];
$ret="select * from registration where emailid=?";
$stmt= $conn->prepare($ret) ;
$stmt->bind_param('s',$aid);
$stmt->execute() ;
$res=$stmt->get_result();
$cnt=1;
while($row=$res->fetch_object())
	  {
	  	?>

<tr>
<td colspan="2"><h4>Room Realted Info :</h4></td>
<td><a href="javascript:void(0);"  onClick="popUpWindow('http://localhost/hostel1/full-profile.php?id=<?php echo $row->emailid;?>');" title="View Full Details">Print Data</a></td>
</tr>

<tr>
<td colspan="3"><b>Reg no. :</b><?php echo $row->postingDate;?></td>
</tr>




<tr>
<td colspan="2"><b>Room no :</b><?php echo $row->roomno;?></td>
<td colspan="1"><b>fee (per month):</b><?php echo $row->fee;?></td>

</tr>

<tr>
<td><b>Food Status:</b>
    <?php if($row->foodstatus==0)
{
echo "Without Food";
}
else
{
echo "With Food";
}
;?>


</td>

<td><b>Stay From :</b><?php echo $row->stayfrom;?></td>

<td><b>Duration:</b><?php echo $dr=$row->duration;?> Months</td>

</tr>


<tr>
<td colspan="3"><h4>Personal Info Info :</h4></td>
</tr>

<tr>

<td><b>Full Name :</b><?php echo $row->firstName;?>&nbsp;<?php echo $row->middleName;?>&nbsp;<?php echo $row->lastName;?></td>

<td><b>Email :</b><?php echo $row->emailid;?></td>

<td><b>Contact No. :</b><?php echo $row->contactno;?></td>

</tr>


<tr>


<td><b>Gender :</b><?php echo $row->gender;?></td>

<td><b>Course :</b><?php echo $row->course;?></td>

<td><b>Emergency Contact No. :</b><?php echo $row->egycontactno;?></td>


</tr>


<tr>

<td><b>Guardian Name :</b><?php echo $row->guardianName;?></td>

<td><b>Guardian Relation :</b><?php echo $row->guardianRelation;?></td>

<td><b>Guardian Contact No. :</b><?php echo $row->guardianContactno;?></td>

</tr>



<tr>
<td colspan="6"><h4>Addresses</h4></td>
</tr>
<tr>
<td colspan="2"><b>Correspondense Address :</b>

   <?php echo $row->corresAddress;?><br />
<?php echo $row->corresCity;?>, <?php echo $row->corresPincode;?><br />
<?php echo $row->corresState;?>

</td>

<td><b>Permanent Address :</b>
   <?php echo $row->pmntAddress;?><br />
<?php echo $row->pmntCity;?>, <?php echo $row->pmntPincode;?><br />
<?php echo $row->pmnatetState;?>
</td>

</tr>



<?php
$cnt=$cnt+1;
} ?>
</tbody>
</table>

</div>
</div>
</div>

	
</body>

<script>
function checkAvailability() {
$("#loaderIcon").show();
jQuery.ajax({
url: "check_availability.php",
data:'roomno='+$("#room").val(),
type: "POST",
success:function(data){
$("#room-availability-status").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}
</script>

</html>