<?php
session_start();
include('dbc/dbconnect.php');
if(isset($_POST['login']))
{
$email=$_POST['email'];
$password=$_POST['psw'];
$stmt=$conn->prepare("SELECT email,password,id FROM userregistration WHERE email=? and password=? ");
				$stmt->bind_param('ss',$email,$password);
				$stmt->execute();
				$stmt -> bind_result($email,$password,$id);
				$rs=$stmt->fetch();
				$stmt->close();
				$_SESSION['id']=$id;
				$_SESSION['login']=$email;
				$uip=$_SERVER['REMOTE_ADDR'];
				$ldate=date('d/m/Y h:i:s', time());
				if($rs)
				{
             $uid=$_SESSION['id'];
             $uemail=$_SESSION['login'];
//$ip=$_SERVER['REMOTE_ADDR'];
//$geopluginURL='http://www.geoplugin.net/php.gp?ip='.$ip;
//$addrDetailsArr = unserialize(file_get_contents($geopluginURL));
//$city = $addrDetailsArr['geoplugin_city'];
//$country = $addrDetailsArr['geoplugin_countryName'];
$log="insert into userlog(userId,userEmail) values('$uid','$uemail')";
$conn->query($log);
if($log)
{
header("location:dashboard.php");
				}
}
				else
				{
					echo "<script>alert('Invalid Username/Email or password');</script>";
				}
			}
				?>

  

 

<html>
<head>
 <meta name="viewport" content="width=device-width", initial-scale=1>
<style>
body {
    font-family: Arial, Helvetica, sans-serif;
	   /* background-color: black;*/
  
}

         .content {
    border: 2px solid #ffffff;
    border-radius: 5px;
    height: 50%;
    margin-left: 195px;
    margin-top: 221px;
    width: 84%;}


    .container-middle {
    margin: 30px auto auto;
    padding: 10px;
    width: 95%;
    }

    .container-middle form {
    border: 4px solid #6E6A78;
    border-radius: 5px;
    font-family: verdana;
    margin: auto;
    padding: 10px 110px 30px;
    width: 64%;
    margin-left: 176px;}

    .form-title {
    border-bottom: 1px dotted #6E6A78;
    color: #3D3D3D;
    margin-top: 5px;
    padding-bottom: 10px;
    text-align: center;}

    .row {
    margin-bottom: 20px;}

    .row label {
    color: #3d3d3d;
    display: inline-block;
    font-size: 14px;
    margin: auto 19px 21px auto;
    text-align: right;
    width: 169px;}


    .container-middle .row input {
    border: 1px solid #6e6a78;
    display: inline-block;
    margin: auto;
    padding: 8px;
    width: 52%;}

    .content .container-middle .button input {
    background-color: #34495e;
    border: 0 none;
    border-radius: 8px;
    color: #fff;
    font-size: 12px;
    font-weight: bold;
    height: 40px;
    margin: 10px 2px;
    width: 100px;
    cursor: pointer;

    }
/*------------------------------------------------*/

.header {
			float:left;
			background-color: slategray;
			color: floralwhite;
			height: 53px;
			position: fixed;
			top: 0;
			width: 85%;
			left:16%;
			
		}
		.title {
			font-family:sans-serif;
			font-size: 40px;
			position: relative;
			top: 5px;
			text-shadow: 1px 0 0;
		}
		.cssmenu{
			width:17%;
			height:100%;
			font-family: cursive;
			position: fixed;
			top: 0px;
			
		}
		.cssmenu, .cssmenu ul, #cssmenu ul li, .cssmenu ul li a{
		    
			margin: 0;
			padding: 0;
			list-style: none;
			line-height: 1;
			display: block;
			background:slategrey
		}
		.cssmenu > ul > li > a {
			padding: 34px 55px;
			border: 1px solid gainsboro;
			border-radius: 10px;
			cursor: pointer;
			color: aqua;
			font-size: 21px;
			text-decoration: none;
			margin:11px;
			font-family: serif;
	  
		}
		.cssmenu > ul > li > a:hover {
		
			background: black;
		}
		
		
		h2 {
              color: chartreuse;
              font-size: 25px;
		      font-family: serif;}
		
	

</style>
</head>

 
 <body>   
                   
    


   <div class="content">            
   <div class="demo container-middle">
  <form action=" " method="post">

 
    <h1>User Login</h1>
    
    <hr><br><br>

	<div class="row">
    <label>Email :</label>
    <input type="text" placeholder="Enter Email" name="email" required>

    <label>Password :</label>
    <input type="password" placeholder="Enter Password" name="psw" required>
     
    <div class="button"> 
    <center><input type="submit" name="login" value="Login"></center>
    </div>
	<a href="forgotpass.php">Forgot password?</a>
  </div>
 

</form>
 </div>
 </div>

	

<div class="side-menubar">
		<div class="header">
			<center> <span class="title">HOSTEL MANAGEMENT SYSTEM</span></center>
		</div>
		<div class='cssmenu' >
			 <center><img src="img/admin2.png" width="200px" height="200px" style="margin-top:10px">
			<h2 style=" padding-bottom: 10px;">Welcome</h2></center>
			<ul>
				<li ><a href="registration.php">user registration</a></li>
				<li ><a href="index.php">user login</a></li>
				<li ><a href="admin/adminlogin.php">admin login</a></li>
				

			</ul>
		</div>
	</div>
</body>	
</html>


