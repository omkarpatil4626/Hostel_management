<?php

include 'dbc/dbconnect.php';
//die("hii");
session_start();

if(isset($_POST['email']) && isset($_POST['psw']))
	{
		 $fn=$_POST['fname'];
         $mn=$_POST['mname'];
         $ln=$_POST['lname'];
         $cn=$_POST['contact'];
         $em=$_POST['email'];
         $ps=$_POST['psw'];
		
		$result = $conn->query("select email from userregistration where email='$em' ");
		
			if($result->num_rows>0)
			{
				?>
                                        <script type="text/javascript">
                                                alert("Email Allready Registered !!!!");
                                                location.href="registration.php";
                                        </script>
                                        <?php
                           
                        }else{
                            
                            $stmt = $conn->prepare("insert into userregistration(firstname,middlename,lastname,contactno,email,password)values(?,?,?,?,?,?)");
                            $stmt->bind_param("ssssss",$fn,$mn,$ln,$cn,$em,$ps);                            
                            $stmt->execute();
                            ?>
                            <script type="text/javascript">
                                    alert("Registered Successful!!!!");
                                    location.href="login.php";
                            </script>
                             <?php
                            
                        }
                            
							
	}
	else
		{
			header("location:index.php");
		}
		
	?>