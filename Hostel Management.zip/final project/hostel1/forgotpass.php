<?php
session_start();
include('dbc/dbconnect.php');
if(isset($_POST['login']))
{
$email=$_POST['email'];
$contact=$_POST['contact'];
$stmt=$conn->prepare("SELECT email,contactno,password FROM userregistration WHERE (email=? && contactno=?) ");
                $stmt->bind_param('ss',$email,$contact);
                $stmt->execute();
                $stmt -> bind_result($username,$email,$password);
                $rs=$stmt->fetch();
                if($rs)
                {
                $pwd=$password;             
                }

                else
                {
                    echo "<script>alert('Invalid Email/Contact no or password');</script>";
                }
            }
                ?>


<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
    font-family: Arial, Helvetica, sans-serif;
  
}

* {
    box-sizing: border-box;
}

/* Add padding to containers */
.container {
    padding: 16px;
    border: 2px solid #adad85;
    width: 40%;
    box-shadow: 2px 2px 15px grey;
	margin: 10% auto auto;
}

/* Full-width input fields */
input[type=text],input[type=password],select,textarea {
    width: 100%;
    padding: 15px;
    margin: 5px 0 22px 0;
    
    border: none;
    background: #f1f1f1;
}

input:focus {
    background-color: #ddd;
    outline: none;
}
label{
	float:left;
}
/* Overwrite default styles of hr */
hr {
    border: 1px solid #f1f1f1;
    margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
    background-color: #4CAF50;
    color: white;
    padding: 16px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 120px;
    border-radius:8px;
}

.registerbtn:hover {
    opacity: 1;
}

a {
    float: right;
    margin: 25px 0 0 0;
}

</style>
</head>
<body>

   

<form action="" method="post">

  <div class="container" style="top:50">
    <center><h1>Forgot Password</h1></center>

      <?php if(isset($_POST['login']))
 { ?>
                    <p>YOUR PASSWORD IS: <?php echo $pwd;?><br> <div class="row" style="color:red;;"> !! CHANGE THE PASSWORD AFTER LOGIN !!</div>
                    </p>
                    <?php }  ?> 
    
    <hr>

	
    <label><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" required>

    <label><b>Contact No</b></label>
    <input type="text" placeholder="Enter contact no" name="contact" required>

    <input type="submit" name="login" class="registerbtn" value="submit">
	<a href="index.php">LOGIN NOW</a>
  </div>

</form>

</body>
</html>
